document.addEventListener('DOMContentLoaded', () => {
  const taskForm = document.getElementById('task-form');
  const taskInput = document.getElementById('task-input');
  const taskList = document.getElementById('task-list');

  taskForm.addEventListener('submit', (e) => {
    e.preventDefault();
    addTask(taskInput.value);
    taskInput.value = '';
  });

  taskList.addEventListener('click', (e) => {
    if (e.target.tagName === 'BUTTON') {
      e.target.parentElement.remove();
      saveTasks();
    } else if (e.target.tagName === 'LI') {
      e.target.classList.toggle('completed');
      saveTasks();
    }
  });

  function addTask(task) {
    const li = document.createElement('li');
    li.textContent = task;
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Eliminar';
    li.appendChild(deleteBtn);
    taskList.appendChild(li);
    saveTasks();
  }

  function saveTasks() {
    const tasks = [];
    taskList.querySelectorAll('li').forEach((li) => {
      tasks.push({
        text: li.firstChild.textContent,
        completed: li.classList.contains('completed'),
      });
    });
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }

  function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.forEach((task) => {
      const li = document.createElement('li');
      li.textContent = task.text;
      if (task.completed) li.classList.add('completed');
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'Eliminar';
      li.appendChild(deleteBtn);
      taskList.appendChild(li);
    });
  }

  loadTasks();
});